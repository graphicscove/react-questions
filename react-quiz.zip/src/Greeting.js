import React from 'react'

const Greeting = ({firstName, lastName}) => (
        <div>Hello {firstName} {lastName}</div>
)

export default Greeting
